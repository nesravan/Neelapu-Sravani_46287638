package com.washer.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.washer.Repository.WasherRepo;
import com.washer.exception.WasherNotFoundException;
import com.washer.model.Washers;
@Service
public class WasherserviceImpl implements WashService {
	@Autowired
	private WasherRepo repo;

	@Override
	public Washers addWasher(Washers washer) {
		// TODO Auto-generated method stub
		return repo.save(washer);
	}

	@Override
	public List<Washers> getwashers() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public List<Washers> getwasherbylocation(String location) {
		// TODO Auto-generated method stub
		
		return repo.findAll();
	}


	@Override
	public String deletewasher(int id) {
	
		 Optional<Washers> optionalWasher = repo.findById(id);

	        if (optionalWasher == null) {
	            throw new WasherNotFoundException("Washer not existing with id: " + id);
	        }
	        Washers washer = optionalWasher.get();
	        repo.delete(washer);
		 return "Deleted sucessfully of Id:"+id;
	}

	 

	
	
	
	
	

}
