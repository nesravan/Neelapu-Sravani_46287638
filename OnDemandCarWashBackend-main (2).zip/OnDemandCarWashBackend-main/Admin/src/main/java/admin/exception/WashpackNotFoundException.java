package admin.exception;



	public class WashpackNotFoundException extends RuntimeException{
		
			  private static final long serialVersionUID = 1L;

			    public WashpackNotFoundException(String message) {
			        super(message);
			    }
	}



