package com.order.Execption;

public class CustomException  extends RuntimeException {
	public CustomException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
		}



		public CustomException() {
		super();
		// TODO Auto-generated constructor stub
		}
}
